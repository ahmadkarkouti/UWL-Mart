<?php
session_start();
$result = 'Login';
session_destroy();


header("Location: index.php");


   


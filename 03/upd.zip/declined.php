<!DOCTYPE html>
<html lang="en">
<head>
    <title>Order Declined - Please Check your details and try again</title>
    <meta charset="utf-8">
    <style>
    .container{width: 100%;padding: 50px;}
    p{color: #FF0000;font-size: 18px;}
    </style>
</head>
</head>
<body>
<div class="container">
    <h1>Order Status</h1>
    <p>Your order has been Declined by the bank</p>
	<p>Please Check your details and try again</p>
	<a href='account.php'>Your account</a>
</div>
</body>
</html>
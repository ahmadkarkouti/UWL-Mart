<?php
session_start(); 
?>

<!DOCTYPE html>
<html>
    
<head>
    
    <meta charset="UTF-8"> <!-- Character set -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="UwlMart">
    <meta name="keywords" content="online, store, shopping, uwl, website">
    <meta name="developers" content="Franck, Ahmad, Mel">
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link rel="stylesheet" type="text/css" href="advancedcss.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="images/png" href="images/logo copy.png" sizes="32x32">
    <link href="http://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" type="text/css">    
    <script type="text/javascript" src="java.js"  charset="utf-8"></script>
    <link rel="stylesheet" href="design.css">
    <title> UWLMart | Employees Page </title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
</head>

<?php  
 
$result = '';
$hide1 = '';
$hide2 = '';
$account = '';
 
if(isset($_SESSION['fname']))  
{  
$result = 'Hello, ' .  $_SESSION['fname'];
$account  = 'account.php';

}  else{
    $result = 'Login';
    $hide1 = '<!-- ';
    $hide2 = ' -->';
    $account = 'login.php';
}
 
 
?>
<body>    
    <div class="topNav">
        <div class="w3-xlarge ">
        <form action="logout.php">
            <ul>
                <li><a href="viewCart.php" class="fa fa-shopping-basket"> Basket </a></li>               
                <li><a href="<?php echo $account; ?>" id="loginitem" id="loginitem" class="fa fa-user-circle-o"><?php echo $result; ?> </a></li>
                <?php echo $hide1; ?> <button type="submit" style="background-color:Transparent;background-repeat:no-repeat;border: none;cursor:pointer;display: inline-flex; align-items: flex-start;";><a>Logout</a></button><?php echo $hide2; ?>
            </ul>
        </form>
        </div>            
    </div>
    
    <header>
        
        <div class="container">
            <div id="brand">
                <p><a href="index.php" ><img src="images/logo.png" alt="UwlMart logo" style="width:250px;height:100px;"></a></p>
            </div>
            <hr /> 
            <ul> 
                <li><a href="index.php" class="fa fa-home"> Home </a></li> 
                <li><a href="groceries.php" class="fa fa-cart-arrow-down"> Groceries </a></li> 
                <li><a href="clothing.php" class="fa fa-tags"> Clothing </a></li>
                <li><a href="<?php echo $account; ?>" class="fa fa-male"> Your account </a></li>
            </ul>
    

</br>
</br>

</body> 

<script>
      /* exported __kof_1*/
      /* exported __kof_2*/
      /* exported __kof_3*/
      /* exported __kof_4*/
      /* exported __kof_5*/
      /* exported __kof_6*/
      /* exported __kof_7*/
      /* exported __kof_8*/
</script>
     
    <div class="tab">
    <button class="tablinks" onclick="openCity(event, 'Groceries');">Add Groceries</button>
    <button class="tablinks" onclick="openCity(event, 'Groceriesdb');">Groceries db</button>
    <button class="tablinks" onclick="openCity(event, 'Clothes');">Add Clothes</button>
    <button class="tablinks" onclick="openCity(event, 'Clothesdb');">Clothes db</button>
    <button class="tablinks" onclick="openCity(event, 'Registration');">Registration</button>
	<button class="tablinks" onclick="openCity(event, 'Orders');">Orders</button>
	<button class="tablinks" onclick="openCity(event, 'OrderItems');">Order items</button>
    <button class="tablinks" onclick="openCity(event, 'Restock');">Restock</button>
    </div>
    
    <fieldset id="Groceries" class="tabcontent">
        </br>
        </br>
        </br>
        </br>
        <form class="w3-container"  action="groceriesadd.php" method="POST">
            <div class="w3-container w3-blue">
                <h2>Add some groceries</h2>
            </div>
                        </br>
                <label>Brand:</label>
            <input type="text" class="w3-input" name="brand" />
                        <br />
                <label>Type & Description:</label>
            <input type="text" class="w3-input" name="type" />
                        <br />
                <label>Stock:</label>
            <input type="text" class="w3-input" name="stock" />
                        <br />
                <label>Price:</label>
            <input type="text" class="w3-input" name="price" />
                        </br>
                <label>Status: 0 or 1</label>
            <input type="text" class="w3-input" name="status" />
                        <br />
                <label>Picture:</label>
            <input type="text" class="w3-input" id="b64" name="picture" value="" />
            <input id="inp" type="file">
            <img id="img" height="150">
            <button type="submit">Add Groceries</button>
            </form>


            <script type="text/javascript"> function readFile() {
            if (this.files && this.files[0]) {
              
              var FR= new FileReader();
              
              FR.addEventListener("load", function(e) {
                document.getElementById("img").src       = e.target.result;
                document.getElementById("b64").value = e.target.result;
              }); 
              
              FR.readAsDataURL( this.files[0] );
              
            }
            
          }
          
          document.getElementById("inp").addEventListener("change", readFile);
            </script>  
        </fieldset>
    <div id="Groceriesdb" class="tabcontent">
        
    
        <h3>Groceries List</h3>
        <table>
            <tr>
			<th>id</th>
            <th>Image</th>
            <th>Brand</th>
            <th>Type</th>
            <th>Stock</th>
            <th>Price</th>
            <th>Delete</th>
            </tr>
            
            
         <?php
        include 'dbh.php';
        $sql = "SELECT * FROM products";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr> <td>". $row['id']. "</td> <td> <img src=". $row['picture']. "></td> <td>"
                . $row["name"]. "</td> <td>" . $row["description"] ."</td> <td>"
                . $row["stock"]. "</td> <td>" . $row["price"] ."</td> <td> <a href='deleteGroceries.php?id=".$row['id']."'>x</a>"."</td></tr>";
                           if($row["stock"] < 1){
                            echo "!!!!!!!!! " .$row['name']. " " .$row["description"] . " is Out of Stock";
                            echo "</br>";
                           }
                                if ($row["stock"] < 10 && $row["stock"] > 0){
                                    echo "!!!!!!!!! " .$row['name']. " " .$row["description"] . " is Low on Stock";
                                    echo "</br>";
                                            
                           }
            }

        } else {
            echo "0 results";
        }
        
        
        ?>
            
        </table>
    </div>
    
    
            
    <fieldset id="Clothes" class="tabcontent">
        </br>
        </br>
        </br>
        </br>
        <form class="w3-container"  action="clothesadd.php" method="POST">
            <div class="w3-container w3-blue">
                <h2>Add some clothes</h2>
            </div>
                        </br>
                <label>Brand:</label>
            <input type="text" class="w3-input" name="brand2" />
                        <br />
                <label>Type & Description:</label>
            <input type="text" class="w3-input" name="type2" />
                        <br />
                <label>Stock:</label>
            <input type="text" class="w3-input" name="stock2" />
                        <br />
                <label>Price:</label>
            <input type="text" class="w3-input" name="price2" />
                        <br />
                <label>Status: 0 or 1</label>
            <input type="text" class="w3-input" name="status2" />
                        <br />
                <label>Picture:</label>
            <input type="text" class="w3-input" id="b65" name="picture2" value="" />
            <input id="inp2" type="file">
            <img id="img2" height="150">
            <button type="submit">Add Clothes</button>
            </form>
        
                    <script type="text/javascript"> function readFile() {
            if (this.files && this.files[0]) {
              
              var FR= new FileReader();
              
              FR.addEventListener("load", function(e) {
                document.getElementById("img2").src       = e.target.result;
                document.getElementById("b65").value = e.target.result;
              }); 
              
              FR.readAsDataURL( this.files[0] );
              
            }
            
          }
          
          document.getElementById("inp2").addEventListener("change", readFile);
            </script> 

        </fieldset>  
    <div id="Clothesdb" class="tabcontent">
        <h3>Clothes List</h3>
        <table>
            <tr>
			<th>id</th>
            <th>Image</th>
            <th>Brand</th>
            <th>Type</th>
            <th>Stock</th>
            <th>Price</th>
            <th>Delete</th>
            </tr>
            
         <?php
        include 'dbh.php';
        $sql = "SELECT * FROM products2";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr> <td>". $row['id']. "</td> <td> <img src=". $row['picture']. "></td> <td>"
                . $row["name"]. "</td> <td>" . $row["description"] ."</td> <td>"
                . $row["stock"]. "</td> <td>" . $row["price"] ."</td> <td> <a href='deleteClothes.php?id=".$row['id']."'>x</a>"."</td></tr>";
                           if($row["stock"] < 1){
                            echo "!!!!!!!!! " .$row['name']. " " .$row["description"] . " is Out of Stock";
                            echo "</br>";
                           }
                                if ($row["stock"] < 10 && $row["stock"] > 0){
                                    echo "!!!!!!!!! " .$row['name']. " " .$row["description"] . " is Low on Stock";
                                    echo "</br>";
                                            
                           }
            }
                          
        } else {
            echo "0 results";
        }
        
        
        ?>
            
        </table>
            
        </table>
    </div>
    <div id="Registration" class="tabcontent">
		<div class="w3-container">
      <h3>Registration List</h3>
        <table>
            <tr>
			<th>id</th>
            <th>FirstName</th>
            <th>LastName</th>
            <th>DOB</th>
            <th>MobileNumber</th>
            <th>Email Address</th>
            <th>AddressLine</th>
            <th>City</th>
            <th>PostCode</th>
            <th>Country</th>
            <th>Delete</th>
                          <?php
        include 'dbh.php';
        $sql = "SELECT * FROM registration";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr> <td>". $row["id"]. "</td> <td>". $row["fname"]."</td> <td>"
                . $row["lname"]. "</td> <td>" . $row["dob"] ."</td> <td>"
                . $row["mnumber"]. "</td> <td>" . $row["eaddress"] ."</td> <td>"
                . $row["address1"]. "</td> <td>" . $row["address2"] ."</td> <td>"
                . $row["pcode"]. "</td> <td>" . $row["country"] ."</td> <td> <a href='deleteRegistration.php?id=".$row['id']."'>x</a>"."</td></tr>";
            }
        } else {
            echo "0 results";
        }
        
        
        ?>
        </table> 
 
      </div>
</div>
		
    <div id="Orders" class="tabcontent">
      <h3>Orders List</h3>
      <div class="w3-container">
        <table id="orderslist">
            <tr>
            <th>id</th>
            <th>customer id</th>
            <th>Total Price</th>
            <th>Created</th>
            <th>Modified</th>
			<th>Delete</th>
                          <?php
        include 'dbh.php';
        $sql = "SELECT * FROM orders";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr> <td>". $row["id"]. "</td> <td>" . $row["customer_id"] ."</td> <td>"
                . $row["total_price"]. "</td> <td>" . $row["created"] ."</td> <td>"
                . $row["modified"]."</td> <td> <a href='deleteOrders.php?id=".$row['id']."'>x</a>"."</td></tr>";
            }
        } else {
            echo "0 results";
        }
        
        
        ?>
        </table>    
 
      </div>
</div>
    <div id="OrderItems" class="tabcontent">
      <h3>Order Items List</h3>
      <div class="w3-container">
        <table id="registrationlist">
            <tr>
            <th>id</th>
            <th>Order id</th>
            <th>Product id</th>
            <th>Quantity</th>
            <th>Delete</th>
                          <?php
        include 'dbh.php';
        $sql = "SELECT * FROM order_items";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr> <td>". $row["id"]. "</td> <td>"
                . $row["order_id"]. "</td> <td>" . $row["product_id"] ."</td> <td>"
                . $row["quantity"]. "</td> <td> <a href='deleteOrderitems.php?id=".$row['id']."'>x</a>"."</td></tr>";
            }
        } else {
            echo "0 results";
        }
        
        
        ?>
        </table>    
 
      </div>
</div>
      
    <fieldset id="Restock" class="tabcontent">
        </br>
        </br>
        </br>
        </br>
        
                <form class="w3-container"  action="restock.php" method="POST">
            <div class="w3-container w3-blue">
                <h2>Restock</h2>
            </div>
                        </br>
                <label>Item Id</label>
            <input type="text" class="w3-input" name="itemid" />
                        <br />
                <label>Add Amount</label>
            <input type="text" class="w3-input" name="addamount" />
                        <br />
            <button type="submit">Add Groceries</button>
            </form>   
    </fieldset>
      







        
</body>

    </header>
</html>